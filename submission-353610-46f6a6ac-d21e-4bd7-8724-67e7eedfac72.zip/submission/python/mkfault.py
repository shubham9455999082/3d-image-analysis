import os
import shutil
import time
import csv

import numpy as np
import hdbscan

import hough


def mk_fault(data_file_path: str, result_directory: str, z_scale=1):

    # create directories to store results, clearing the results directory if it already exists
    shutil.rmtree(result_directory, ignore_errors=True)

    os.mkdir(result_directory)
    os.mkdir(f'{result_directory}/clusters')
    os.mkdir(f'{result_directory}/planes')
    os.mkdir(f'{result_directory}/meshes')
    os.mkdir(f'{result_directory}/accumulators')

    log_file = open(f'{result_directory}/log.txt', 'w')

    def log(line: str):
        print(line, file=log_file)

    log('beginning fault detection')

    start_time = time.time()

    # first count how many lines are in the data file to pre-size data array
    with open(data_file_path) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        n_data = 0
        for _ in csv_reader:
            n_data += 1
        csv_file.close()

    data = np.empty([n_data, 4])

    # now load data into array
    with open(data_file_path) as csv_file:
        dif_csv_reader = csv.reader(csv_file, delimiter=',')
        count = 0
        for row in dif_csv_reader:
            data[count] = [float(row[0]), float(row[1]), float(row[2]), float(row[3])]
            # positions[count] = [float(row[0]), float(row[1]), float(row[2])]
            count += 1
        csv_file.close()

    time_marker = time.time()
    log(f'scanned {n_data} data points in {time_marker - start_time}s')

    clusters = cluster_data(data)
    for cluster in clusters:
        if len(cluster) > 150000:
            sub_clusters = cluster_data(cluster)
            clusters.remove(cluster)
            clusters.append(sub_clusters)

    min_cluster_size = 1000
    cluster_count = 0
    log('writing clusters to files')
    for cluster in clusters:
        if len(cluster) >= min_cluster_size:
            os.mkdir(f'{result_directory}/accumulators/{cluster_count}')
            os.mkdir(f'{result_directory}/planes/{cluster_count}')
            os.mkdir(f'{result_directory}/meshes/{cluster_count}')
            with open(f'{result_directory}/clusters/{cluster_count}.csv', mode='w') as cluster_file:
                writer = csv.writer(cluster_file, delimiter=',')
                for point in cluster:
                    writer.writerow(point)
            cluster_count += 1

    log(f'clustering complete {cluster_count} clusters survived {min_cluster_size} point size threshold')

    for i in range(cluster_count):
        log('')
        log(f'beginning hough transform on cluster {i}')
        time_marker = time.time()
        hough.process(i, result_directory, z_scale=z_scale, skip_hough=False,  n_rho=200, n_phi=40, n_theta=80)
        log(f'cluster {i} transformed and processed in {time.time() - time_marker}s')

    log('collecting meshes')
    collect_meshes(result_directory)
    log(f"total processing time {time.time() - start_time}")


def cluster_data(data: np.ndarray) -> list:
    # performs HDBSCAN clustering on the input data
    # returns a list of numpy arrays containing the clustered data points

    clusterer = hdbscan.HDBSCAN(min_cluster_size=35)
    cluster_labels = clusterer.fit_predict(data)
    n_clusters = cluster_labels.max() + 1

    # calculate the size of each cluster and store in array
    cluster_sizes = np.zeros(n_clusters, int)
    for index, label in enumerate(cluster_labels):
        if label == -1:
            continue
        cluster_sizes[label] += 1
    # initialize list of numpy arrays to store each cluster
    clusters = list()
    for index in range(n_clusters):
        clusters.append(np.zeros([cluster_sizes[index], 4]))

    # fill cluster list from data
    cluster_indices = np.zeros(n_clusters, int)
    for index, label in enumerate(cluster_labels):
        if label == -1:
            continue
        cluster_index = cluster_indices[label]
        clusters[label][cluster_index] = data[index]
        cluster_indices[label] += 1

    return clusters

def collect_meshes(result_directory: str):
    # collect mesh files from individual cluster directors and put them all in the output directory
    shutil.rmtree(f'{result_directory}/output', ignore_errors=True)
    os.mkdir(f'{result_directory}/output')
    mesh_dirs = [f.name for f in os.scandir(f'{result_directory}/meshes') if f.is_dir()]
    for dir in mesh_dirs:
        mesh_files = [f.name for f in os.scandir(f'{result_directory}/meshes/{dir}')]
        for file in mesh_files:
            shutil.copy(f'{result_directory}/meshes/{dir}/{file}',
                        f'{result_directory}/output/cluster_{dir}_mesh_{file}')
