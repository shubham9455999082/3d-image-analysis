import numpy as np
import math
import time
import csv
import shutil
import os

import helpers as hlp
import mkmesh


def process(cluster_index,
            result_path,
            z_scale=1,
            skip_hough=False,
            skip_meshing=False,
            n_rho=200,
            n_phi=30,
            n_theta=60,
            max_distance=3000,
            peak_threshold=0.4,
            peak_filter_dims=np.array([20, 10, 20]),
            max_planes=10):

    cluster_path = f'{result_path}/clusters/{cluster_index}.csv'
    plane_path = f'{result_path}/planes/{cluster_index}'
    mesh_path = f'{result_path}/meshes/{cluster_index}'
    accumulator_path = f'{result_path}/accumulators/{cluster_index}'

    # clear any previously generated meshes and planes
    shutil.rmtree(plane_path, ignore_errors=True)
    shutil.rmtree(mesh_path, ignore_errors=True)
    os.mkdir(plane_path)
    os.mkdir(mesh_path)
    # read cluster data file and count number of lines
    with open(cluster_path) as file:
        reader = csv.reader(file, delimiter=',')
        size = sum(1 for _ in reader)
        file.close()

    cluster = np.empty([size, 4])

    # arrays to store coordinate bounds for shifting
    x_bounds = np.array([np.inf, -np.inf])
    y_bounds = np.array([np.inf, -np.inf])
    z_bounds = np.array([np.inf, -np.inf])

    def update_bounds(point_: np.ndarray):
        if point_[0] < x_bounds[0]:
            x_bounds[0] = point_[0]
        elif point_[0] > x_bounds[1]:
            x_bounds[1] = point_[0]

        if point_[1] < y_bounds[0]:
            y_bounds[0] = point_[1]
        elif point_[1] > y_bounds[1]:
            y_bounds[1] = point_[1]

        if point_[2] < z_bounds[0]:
            z_bounds[0] = point_[2]
        elif point_[2] > z_bounds[1]:
            z_bounds[1] = point_[2]

    # now we read the cluster file again, this time copying data into the numpy cluster array and calculating bounds
    with open(cluster_path) as file:
        reader = csv.reader(file, delimiter=',')
        for index, row in enumerate(reader):
            cluster[index] = [row[0], row[1], row[2], row[3]]
            update_bounds(cluster[index])
        file.close()

    # shift the cluster to the origin
    for index, cluster_point in enumerate(cluster):
        shifted_point = cluster_point
        shifted_point[0] -= x_bounds[0]
        shifted_point[1] -= y_bounds[0]
        shifted_point[2] -= z_bounds[0]
        cluster[index] = shifted_point

    # calculate the max distance from the origin a plane could be and multiply by 1.2 for sanity
    rho_max = 1.2 * math.sqrt((x_bounds[1] - x_bounds[0]) * (x_bounds[1] - x_bounds[0]) +
                              (y_bounds[1] - y_bounds[0]) * (y_bounds[1] - y_bounds[0]) +
                              (z_bounds[1] - z_bounds[0]) * (z_bounds[1] - z_bounds[0]))

    if skip_hough:
        print('skipping transform and loading a previous accumulator')
        accumulator = np.load(f'{accumulator_path}/a.npy')
        # import parameters used to generate accumulator
        with open(f"{accumulator_path}/params.csv") as file:
            reader = csv.reader(file, delimiter=',')
            for row in reader:
                n_rho = int(row[0])
                n_phi = int(row[1])
                n_theta = int(row[2])
            file.close()
        print(f'reusing accumulator with {[n_rho, n_phi, n_theta]}')
    else:
        accumulator = transform(cluster, rho_max, n_rho, n_phi, n_theta)
        np.save(f'{accumulator_path}/a', accumulator)
        with open(f'{accumulator_path}/params.csv', 'w') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow([n_rho, n_phi, n_theta])
            file.close()

    if skip_meshing:
        return

    # detect peaks in the accumulator using image processing functions from scipy
    peaks = hlp.detect_peaks(accumulator, peak_filter_dims)

    # shift points back to their original position
    for index, cluster_point in enumerate(cluster):
        shifted_point = cluster_point
        shifted_point[0] += x_bounds[0]
        shifted_point[1] += y_bounds[0]
        shifted_point[2] += z_bounds[0]
        cluster[index] = shifted_point

    max_weight = np.amax(accumulator)

    # only select peaks that are above threshold * max_weight
    # threshold = 0.4
    weights = []
    for i, x in enumerate(peaks[0]):
        y = peaks[1][i]
        z = peaks[2][i]
        if accumulator[x, y, z] >= peak_threshold * max_weight:
            weights.append([accumulator[x, y, z], [x, y, z]])

    n_planes = min(max_planes, len(weights))
    planes = np.ndarray((n_planes, 4))
    plane_points = []
    weights.sort(reverse=True)

    counter = 0
    for w in weights[:max_planes]:
        coords = hlp.spherical_from_accumulator_indices(w[1], rho_max, n_rho, n_phi, n_theta)

        # calculate the hessian form of the plane n*p = rho, returning (nx, ny, nz, rho) and shift back to original xyz
        plane = hlp.hessian_form_with_offset(coords, np.asarray([-x_bounds[0], -y_bounds[0], -z_bounds[0]]))

        # filter out planes that are exactly parallel to the ground since these will be preferentially weighted
        if math.fabs(plane[0]) < 0.0001 and math.fabs(plane[1]) < 0.0001:
            continue

        planes[counter] = plane

        # get the points that are within a distance of the plane and save them
        points = hlp.decide_points_plane(cluster, plane, max_distance)
        if len(points) == 0:
            continue

        plane_points.append(points)

        # save planes and close points for reference
        with open(f'{plane_path}/{counter}.csv', mode='w') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow(plane)
            for p in points:
                writer.writerow([p[0], p[1], p[2]])
            file.close()
        counter += 1

    # calculate convex hulls and meshes for each plane
    for index, points in enumerate(plane_points):
        plane = planes[index]
        mkmesh.mesh(plane, points, mesh_path, index, z_scale)


def transform(cluster_points: np.ndarray, rho_max, n_rho, n_phi, n_theta_max):
    start_time = time.time()
    pi = np.pi
    d_rho = rho_max / n_rho
    d_phi = pi / (n_phi - 1)
    d_theta = 2 * pi / n_theta_max

    # print("beginning hough with calculated parameters:")
    # print(f"rho: {n_rho} steps of {d_rho} between 0 and {rho_max}")
    # print(f"phi: {n_phi} steps of {d_phi} between 0 and pi")
    # print(f"theta: {n_theta_max} steps of {d_theta} between 0 and 2pi")

    # calculate the number of theta values at a given latitude
    def n_theta_i(phi_i):
        # if phi_i == 0 or abs(phi_i - pi) < 0.00000001:
        #     return 1
        n = math.floor(2 * pi * np.sin(phi_i) / d_theta)
        if n == 0:
            return 1
        return n

    # calculate the size of a theta step at a given latitude
    def d_theta_i(phi_i):
        n = n_theta_i(phi_i)
        return 2 * pi / n

    # create an array to store phi values for quick reference
    phi_values = np.empty(n_phi)
    phi_sum = 0
    for i in range(n_phi):
        phi_values[i] = phi_sum
        phi_sum += d_phi

    # precalculate trig tables
    sin_phi = np.empty(n_phi)
    sin_theta = np.empty([n_phi, n_theta_max + 1])

    cos_phi = np.empty(n_phi)
    cos_theta = np.empty([n_phi, n_theta_max + 1])

    for i, phi in enumerate(phi_values):

        sin_phi[i] = np.sin(phi)
        cos_phi[i] = np.cos(phi)

        theta_val = 0

        n = n_theta_i(phi)
        d = d_theta_i(phi)

        for j in range(n):

            sin_theta[i, j] = np.sin(theta_val)
            cos_theta[i, j] = np.cos(theta_val)
            theta_val += d

    # the number of theta values for a given phi index, to use as bounds in the inner for loop below
    n_thetas = np.zeros(n_phi, int)
    for i, phi in enumerate(phi_values):
        n_thetas[i] = n_theta_i(phi)

    # create the accumulator
    accumulator = np.zeros([n_rho, n_phi, n_theta_max])


    def vote(cluster_point):
        x = cluster_point[0]
        y = cluster_point[1]
        z = cluster_point[2]
        for i in range(n_phi):
            for j in range(n_thetas[i]):
                rho = x * sin_phi[i] * cos_theta[i, j] + y * sin_phi[i] * sin_theta[i, j] + z * cos_phi[i]
                rho_bin = math.floor(rho / d_rho)
                if n_rho > rho_bin >= 0:
                    accumulator[rho_bin, i, j] += cluster_point[3]  # weight the vote by the fault likelihood

    # uncomment this to save the accumulator angles to check its structure

    # with open("../accumulator.csv", "w") as file:
    #     writer = csv.writer(file, delimiter=',')
    #     phi = 0
    #     for i in range(n_phi):
    #         n =  n_theta_i(phi)
    #         d = d_theta_i(phi)
    #         theta = 0
    #         # if n == 0:
    #         #     writer.writerow([np.sin(phi) * np.cos(theta), np.sin(phi) * np.sin(theta), np.cos(phi)])
    #         for t in range(n):
    #             writer.writerow([np.sin(phi) * np.cos(theta), np.sin(phi) * np.sin(theta), np.cos(phi)])
    #             theta += d
    #         phi += d_phi
    #     file.close()

    for cluster_p in cluster_points:
        vote(cluster_p)

    return accumulator
