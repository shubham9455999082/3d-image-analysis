import numpy as np
import hdbscan
import math
import os
import shutil
import csv

from numpy.linalg import inv
from scipy.spatial import ConvexHull
import openmesh

import helpers as hlp


def mesh(plane: np.array, points: np.ndarray, path: str, identifier, z_scale):
    """
    mesh takes a plane in hessian form (nx, ny, nz, rho) and an array of points close to the plane
    - first the points are clustered to find connected regions, and the largest cluster is chosen
    - the points are then projected onto the plane to remove one dimension
    - then the points transformed into a coordinate system lying entirely in the plane
    - the 2d convex hull of the points is then calculated
    - the points in the hull are then transformed back into 3d space
    - a mesh is then created from the hull and saved
    """

    # first cluster the point to find connected regions
    if len(points) == 0:
        print(f'no points, skipping mesh')
        return

    clusterer = hdbscan.HDBSCAN(min_cluster_size=50)
    cluster_labels = clusterer.fit_predict(points)
    n_clusters = cluster_labels.max() + 1
    if n_clusters == 0:
        print(f'no clusters found to mesh, skipping')
        return
    # calculate the size of each cluster and store in array
    cluster_sizes = np.zeros(n_clusters, int)
    for index, label in enumerate(cluster_labels):
        if label == -1:
            continue
        cluster_sizes[label] += 1

    # initialize list of numpy arrays to store each cluster
    clusters = list()
    for index in range(n_clusters):
        clusters.append(np.zeros([cluster_sizes[index], 3]))

    # fill cluster list from data
    cluster_indices = np.zeros(n_clusters, int)
    for index, label in enumerate(cluster_labels):
        if label == -1:
            continue
        cluster_index = cluster_indices[label]
        clusters[label][cluster_index] = points[index][0:3]
        cluster_indices[label] += 1

    # only take planes that have sub_cluster_threshold points close enough to them
    # (to weed out tiny planes and multiple intersections)
    sub_cluster_threshold = 100
    largest_cluster = clusters[np.argmax(cluster_sizes)]
    if len(largest_cluster) < sub_cluster_threshold:
        return

    projected = hlp.project_points_onto_plane(largest_cluster, plane)

    # get the normal vector of the plane, perpendicular to its surface
    n = np.array([plane[0], plane[1], plane[2]])

    # now calculate the basis vectors for the coordinate system inside the plane
    # to find the first we simple take any two of our projected points and get the vector between them
    # e1 will be perpendicular to n by definition
    e1 = (projected[0] - projected[1])
    e1 = e1 / math.sqrt(np.dot(e1, e1))  # normalize the first basis vector

    # we can now get a second basis vector perpendicular to both n and e1 by taking the cross product n x e1
    e2 = np.cross(e1, n)  # e2 is normalized since both n1 and e1 already are

    # now create the change of base matrices
    backward_cob = np.array([e1, e2, n]).transpose()  # plane to normal space
    forward_cob = inv(backward_cob)  # normal space to plane

    # array to hold the points in the plane coordinate system
    cobbed_points = np.ndarray([len(projected), 2])
    # save the n component (should be the same for all cobbed points) in order to transform back to normal space
    n_component = np.dot(forward_cob, projected[0])[2]
    # now transform all the points into the plane coordinate system, taking only the e1 and e2 components
    for i, projected_point in enumerate(projected):
        cobbed_points[i] = np.dot(forward_cob, projected_point)[0:2]

    # calculate the 2d convex hull of the transformed points
    flat_hull = ConvexHull(cobbed_points)

    # now we transform the vertices of the hull back into normal space, adding back in the n component to return to 3D
    full_hull = np.ndarray([len(flat_hull.vertices), 3])
    for k, index in enumerate(flat_hull.vertices):
        cobbed_point = cobbed_points[index]
        full_hull[k] = np.dot(backward_cob, [cobbed_point[0], cobbed_point[1], n_component])

    # save hulls for reference
    # with open(f'{path}/hulls/' + f'{identifier}.csv', mode='w') as file:
    #     writer = csv.writer(file, delimiter=',')
    #     for point in full_hull:
    #         writer.writerow(point)
    #     file.close()

    hlp.save_mesh_from_hull_3d(full_hull, f'{path}/{identifier}.txt', z_scale)
