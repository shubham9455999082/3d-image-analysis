import numpy as np
import math
from scipy.ndimage.filters import maximum_filter
from scipy.ndimage.morphology import binary_erosion


def spherical_from_accumulator_indices(coords, rho_max, n_rho, n_phi, n_theta_max) -> np.array:
    # get the spherical coordinates of a plane in Hough Space from the indices of the accumulator cell

    pi = np.pi
    d_rho = rho_max / n_rho
    d_phi = pi / (n_phi - 1)
    d_theta = 2 * pi / n_theta_max

    def n_theta_i(phi_i):
        # if phi_i == 0 or abs(phi_i - pi) < 0.00000001:
        #     return 1
        n = math.floor(2 * pi * np.sin(phi_i) / d_theta)
        if n == 0:
            return 1
        return n

    def d_theta_i(phi_i):
        n = n_theta_i(phi_i)
        return 2 * pi / n

    return [(coords[0] + 0.5) * d_rho, coords[1] * d_phi, coords[2] * d_theta_i(coords[1] * d_phi)]


def detect_peaks(data, dims):
    # modified from https://stackoverflow.com/a/3689710

    neighborhood = np.ones((dims[0], dims[1], dims[2]), dtype=bool)
    # apply the local maximum filter; all pixel of maximal value
    # in their neighborhood are set to 1

    local_max = maximum_filter(data, footprint=neighborhood) == data
    # local_max is a mask that contains the peaks we are
    # looking for, but also the background.
    # In order to isolate the peaks we must remove the background from the mask.

    # we create the mask of the background
    background = (data == 0)

    # a little technicality: we must erode the background in order to
    # successfully subtract it form local_max, otherwise a line will
    # appear along the background border (artifact of the local maximum filter)
    eroded_background = binary_erosion(background, structure=neighborhood, border_value=1)

    # we obtain the final mask, containing only peaks,
    # by removing the background from the local_max mask (xor operation)
    detected_peaks = local_max ^ eroded_background

    return np.where(detected_peaks)


def hessian_form_no_offset(coords):
    return np.array([np.sin(coords[1])*np.cos(coords[2]), np.sin(coords[1])*np.sin(coords[2]), np.cos(coords[1]), coords[0]])


def hessian_form_with_offset(spherical_coords, offset: np.ndarray):
    # calculates the hessian form of a plane and with a vector offset
    # if you're reversing an offset done previously, you need to give this function the negative of the offset
    rho = spherical_coords[0]
    phi = spherical_coords[1]
    theta = spherical_coords[2]
    n = np.array([np.sin(phi)*np.cos(theta), np.sin(phi)*np.sin(theta), np.cos(phi)])
    return [n[0], n[1], n[2], rho - np.dot(n, offset)]


def distance(point: np.ndarray, plane: np.ndarray) -> float:
    # distance from a point to a plane, where the plane is represented as (nx, ny, nz, rho)
    d = np.dot(point, plane[0:3]) - plane[3]  # signed distance
    return math.fabs(d)


def decide_points_plane(cluster_array: np.ndarray, plane, distance_threshold):
    # decide which points belong to a plane using a simple distance threshold

    plane_points = np.empty(cluster_array.shape)
    count = 0
    for cluster_point in cluster_array:
        if distance(cluster_point[0:3], plane) <= distance_threshold:
            plane_points[count] = cluster_point
            count += 1
    return plane_points[0: count] if count != 0 else np.array([])


def project_points_onto_plane(point_cluster, plane) -> np.ndarray:
    projected_points = np.ndarray(point_cluster.shape)
    n = np.array([plane[0], plane[1], plane[2]])
    rho = plane[3]
    for i, p in enumerate(point_cluster):
        projected_points[i] = p - (np.dot(n, p) - rho) * n
    return projected_points


def save_mesh_from_hull_3d(hull: np.ndarray, save_path: str, z_scale):
    # z_scale = 1000
    # z_scale = 10
    coordinate_sum = np.zeros(3)
    n_edges = len(hull)
    for edge in hull:
        coordinate_sum += edge
    center_point = coordinate_sum / n_edges

    # scale the z axis back to the original 0 - 200
    # NOTE that all saved cluster points and planes have not been unscaled
    center_point = np.array([1, 1, 1.0/z_scale]) * center_point
    scaled_hull = np.array([1, 1, 1.0/z_scale]) * hull

    with open(save_path, "w") as file:
        file.write(f'{n_edges + 1}\n')
        for edge in scaled_hull:
            file.write(f"{edge[0]} {edge[1]} {edge[2]}\n")
        file.write(f"{center_point[0]} {center_point[1]} {center_point[2]}\n")

        file.write(f'{n_edges}\n')
        for i in range(1, n_edges):
            file.write(f"{i} {i + 1} {n_edges + 1}\n")
        file.write(f"{n_edges} {1} {n_edges + 1}\n")
